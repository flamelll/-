PythonTest1.py直接用pycharm运行然后挂着不关闭，就定时爬取。（服务器）
PythonTest.py就是直接爬取

testo.py爬取到wangye数据库的new表，再利用中文分词工具进行分词，再导入数据库疫情当中去
中文分词网站：https://wordart.com/create